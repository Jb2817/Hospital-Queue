from specialization_queue import SpecializationQueue
from patient import Patient

class PatientManagement:
    """
    Class to manage patients
    Create and manage patient records (name, urgencystatus)
    Assign patients to specialization queues
    """
    def __init__(self):
        self.patients = {}
        self.specialization_queues = {}
        self.specialization_queues['General'] = SpecializationQueue('General')
        self.specialization_queues['Cardiology'] = SpecializationQueue('Cardiology')
        self.specialization_queues['Neurology'] = SpecializationQueue('Neurology')
        self.specialization_queues['Orthopedics'] = SpecializationQueue('Orthopedics')
        self.specialization_queues['Pediatrics'] = SpecializationQueue('Pediatrics')
        self.specialization_queues['Oncology'] = SpecializationQueue('Oncology')


    def add_patient(self, name, urgency_status, timestamp, specialization):
        if specialization not in self.specialization_queues:
            print("Invalid specialization")
            return
        new_patient = Patient(name, urgency_status, timestamp)
        
        # Add patient to the patients dictionary
        self.patients[name] = specialization
        self.specialization_queues[specialization].enqueue(new_patient)
        

    # remove the patient from the queue    
    def remove_patient(self, name):
        if name in self.patients:
            specialization = self.patients[name]
            if self.specialization_queues[specialization].contains(name):
                self.specialization_queues[specialization].remove(name)
                del self.patients[name]
                return True
        return False
    
    # get the next patient from the queue
    def get_patient(self, specialization):
        if specialization not in self.specialization_queues:
            print("Invalid specialization")
            return None
        return self.specialization_queues[specialization].dequeue()

    def get_avg_waiting_time(self, specialization, current_time):
        print(current_time)
        if specialization not in self.specialization_queues:
            print("Invalid specialization")
            return 0
        return self.specialization_queues[specialization].get_avg_waiting_time(current_time)
    
    def update_patient_urgency(self, name, urgency_status):
        if name in self.patients:
            specialization = self.patients[name]
            for patient in self.specialization_queues[specialization].queue:
                if patient.name == name:
                    patient.urgency_status = urgency_status
                    return True
        return False

    def get_all_specializations(self):
        return list(self.specialization_queues.keys())
    
    def list_queues(self):
        queue_summary = {}
        for spec, queue in self.specialization_queues.items():
            queue_summary[spec] = [patient.name for patient in queue.queue]
        return queue_summary
    
    def get_patient_by_name(self, name):
        if name in self.patients:
            specialization = self.patients[name]
            for patient in self.specialization_queues[specialization].queue:
                if patient.name == name:
                    return patient
        return None
    
    @staticmethod
    def format_patient_urgency(urgency_level):
        if urgency_level == 0:
            return "Normal"
        elif urgency_level == 1:
            return "Urgent"
        elif urgency_level == 2:
            return "Super Urgent"
        else:
            return "Unknown"