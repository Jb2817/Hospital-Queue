import cmd
import time
from patient_management import PatientManagement
from datetime import datetime, timedelta

class HospitalCLI(cmd.Cmd):
    intro = 'Welcome to the Hospital CLI. Type help or ? to list commands.\n'
    prompt = 'Hospital_mgmt> '

    def __init__(self):
        super().__init__()
        self.patient_management = PatientManagement()

    def list_specializations(self):
        specializations = self.patient_management.get_all_specializations()
        print("Available specializations are: " + ", ".join(specializations))

    def convert_to_timestamp(self, time_str):
        try:
            hours, minutes = map(int, time_str.split(':'))
            now = datetime.now()
            target_date = datetime(year=now.year, month=now.month, day=now.day,
                                   hour=0, minute=0, second=0, microsecond=0)
            future_time = target_date + timedelta(hours=hours, minutes=minutes)
            return int(future_time.timestamp())
        except ValueError:
            print("Invalid time format. Please use DD:HH:MM for time.")
            return None

    def do_add_patient(self, arg):
        'Add a new patient interactively.'
        print("You are about to add a new patient.")
        name = input("Enter patient's name: ")
        urgency_status = input("Enter urgency status (0=normal, 1=urgent, 2=super urgent): ")
        time_input = input("Enter timestamp (HH:MM): ")
        self.list_specializations()
        specialization = input("Enter specialization from the list above: ")

        timestamp = self.convert_to_timestamp(time_input)
        if timestamp is None:
            return

        try:
            urgency_status = int(urgency_status)
            self.patient_management.add_patient(name, urgency_status, timestamp, specialization)
            print(f"Patient {name} added to {specialization}.")
        except ValueError:
            print("Urgency status must be an integer.")

    def do_remove_patient(self, arg):
        'Remove a patient by name after confirmation.'
        if not arg:
            arg = input("Please enter the name of the patient to remove: ")
            if not arg:
                print("No name provided.")
                return

        confirm = input(f"Are you sure you want to remove patient {arg}? (yes/no): ")
        if confirm.lower() == 'yes':
            success = self.patient_management.remove_patient(arg)
            if success:
                print(f"Patient {arg} removed.")
            else:
                print(f"Patient {arg} not found or could not be removed.")
        else:
            print("Operation cancelled.")
    
    def do_list_queues(self, arg):
        'List all patient queues by specialization.'
        queues = self.patient_management.list_queues()
        if queues:
            for spec, patients in queues.items():
                print(f"{spec}: {', '.join(patients)}")
        else:
            print("There are no patients in any queue.")

    def do_get_patient(self, arg):
        'Get the next patient from a specialization.'
        if not arg:
            self.do_list_specializations('')
            arg = input("Please provide a specialization from the list above: ")
        patient = self.patient_management.get_patient(arg)
        if patient:
            print(f"Next patient for {arg}: {patient}")
        else:
            print(f"No patients in queue for {arg}.")

    def do_avg_waiting_time(self, arg):
        'Get the average waiting time for a specialization.'
        if not arg:
            self.do_list_specializations('')
            arg = input("Please provide a specialization from the list above: ")
        current_time = int(time.time())
        avg_waiting_time = self.patient_management.get_avg_waiting_time(arg, current_time)
        if avg_waiting_time is not None:
            print(f"Average waiting time for {arg} is approximately {avg_waiting_time:.2f} minutes.")
        else:
            print(f"Could not calculate average waiting time for {arg}.")

    def do_exit(self):
        'Exit the CLI.'
        print("Exiting the hospital management system.")
        return True

if __name__ == '__main__':
    HospitalCLI().cmdloop()
