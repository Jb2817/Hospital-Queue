class Patient:
    """
    This class represents a patient in the medical department.
    """
    def __init__(self, name, urgency_status, timestamp):
        self.name = name
        self.urgency_status = urgency_status
        self.arrival_time = timestamp

    def __str__(self):
        return f"{self.name} is {self.format_patient_urgency(self.urgency_status)}"
    
    def set_name(self, name):
        self.name = name

    def set_urgency_status(self, urgency_status):
        self.urgency_status = urgency_status
    
    def set_timestamp(self, timestamp):
        self.arrival_time = timestamp

    def get_waiting_time(self, current_time):
        return (current_time - self.arrival_time) / 60
