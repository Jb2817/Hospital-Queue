from patient import Patient

class SpecializationQueue:
    def __init__(self, name):
        self.queue = []
        self.name = name
        self.capacity = 10 # default capacity

    def enqueue(self, patient):
        inserted = False

        # Check if the queue is full or give an warning
        if len(self.queue) >= self.capacity:
            raise Exception("Queue is full")
        
        for i in range(len(self.queue)):
            if self.queue[i].urgency_status < patient.urgency_status:
                self.queue.insert(i, patient)
                inserted = True
                break
        if not inserted:
            self.queue.append(patient)

    def dequeue(self):
        if len(self.queue) == 0:
            return None
        return self.queue.pop(0)

    def is_empty(self):
        return len(self.queue) == 0

    def __str__(self):
        return str(self.queue)
    
    def contains(self, name):
        for patient in self.queue:
            if patient.name == name:
                return True
        return False
    
    def remove(self, name):
        for patient in self.queue:
            if patient.name == name:
                self.queue.remove(patient)
                return True
        return
    
    def get_avg_waiting_time(self, current_time):
        if len(self.queue) == 0:
            return 0
        total_waiting_time = 0
        for patient in self.queue:
            total_waiting_time += patient.get_waiting_time(current_time)
        return total_waiting_time / len(self.queue)