import tkinter as tk
from tkinter import simpledialog, messagebox, ttk
from tkinter import Toplevel
from patient_management import PatientManagement
from datetime import datetime, timedelta

class HospitalGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Hospital Management System")
        self.patient_management = PatientManagement()

        # Layout
        self.frame = tk.Frame(self.root)
        self.frame.pack(padx=10, pady=10)

        title_label = tk.Label(self.frame, text="Hospital Patient Management", font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10))

        self.specializations = ['Cardiology', 'Neurology', 'Orthopedics', 'Pediatrics', 'General Medicine']

        tk.Button(self.frame, text="Add Patient", command=self.add_patient).grid(row=1, column=0, padx=5, pady=5)
        tk.Button(self.frame, text="Remove Patient", command=self.remove_patient).grid(row=1, column=1, padx=5, pady=5)
        tk.Button(self.frame, text="Get Next Patient", command=self.get_next_patient).grid(row=2, column=0, padx=5, pady=5)
        tk.Button(self.frame, text="View/Edit Patient", command=self.view_edit_patient).grid(row=2, column=1, padx=5, pady=5)
        tk.Button(self.frame, text="Show Queues", command=self.show_queues).grid(row=3, column=0, padx=5, pady=5)
        tk.Button(self.frame, text="Show Queue Statistics", command=self.show_queue_statistics).grid(row=3, column=1, padx=5, pady=5)
        tk.Button(self.frame, text="Exit", command=self.root.quit).grid(row=4, column=0, columnspan=2, padx=5, pady=5)


        self.queue_label = tk.Label(self.frame, text="")
        self.queue_label.grid(row=3, column=0, columnspan=2, pady=10)

    def add_patient(self):
        name = simpledialog.askstring("Input", "Enter patient's name:", parent=self.root)
        if not name:
            return
        urgency_status = simpledialog.askinteger("Input", "Enter urgency status (0=normal, 1=urgent, 2=super urgent):", parent=self.root)
        if urgency_status is None:
            return
        time_input = simpledialog.askstring("Input", "Enter timestamp (HH:MM):", parent=self.root)
        if not time_input:
            return

        self.open_add_patient_dialog(name, urgency_status, time_input)

    def open_add_patient_dialog(self, name, urgency_status, time_input):
        self.add_patient_window = tk.Toplevel(self.root)
        self.add_patient_window.title("Add Patient")
        self.add_patient_window.geometry("300x100")

        specialization = tk.StringVar()
        specialization_dropdown = ttk.Combobox(self.add_patient_window, textvariable=specialization, values=self.specializations)
        specialization_dropdown.set('Select Specialization')
        specialization_dropdown.pack(pady=10)
        specialization_dropdown.bind("<<ComboboxSelected>>", lambda event: self.confirm_add_patient(name, urgency_status, time_input, specialization.get(), self.add_patient_window))

    def confirm_add_patient(self, name, urgency_status, time_input, specialization, window):
        if specialization == 'Select Specialization':
            messagebox.showerror("Error", "Please select a specialization.")
            return
        ts = self.convert_to_timestamp(time_input)
        self.patient_management.add_patient(name, urgency_status, ts, specialization)
        messagebox.showinfo("Info", f"Patient {name} added to {specialization}.")
        window.destroy()

    def get_next_patient(self):
        # Specialization selection via dropdown
        specialization = tk.StringVar()
        specialization_dropdown = ttk.Combobox(self.root, textvariable=specialization, values=self.specializations)
        specialization_dropdown.set('Select Specialization')
        specialization_dropdown.pack()

        next_btn = tk.Button(self.root, text="Get Next", command=lambda: self.confirm_get_next_patient(specialization.get(), specialization_dropdown))
        next_btn.pack()

    def confirm_get_next_patient(self, specialization, dropdown_widget):
        if specialization == 'Select Specialization':
            return
        
        patient = self.patient_management.get_patient(specialization)
        if patient:
            messagebox.showinfo("Next Patient", f"Next patient for {specialization}: {patient}")
        else:
            messagebox.showinfo("Next Patient", f"No patients in queue for {specialization}")
        dropdown_widget.destroy()

    def remove_patient(self):
        name = simpledialog.askstring("Input", "Enter the name of the patient to remove:", parent=self.root)
        if name:
            confirm = messagebox.askyesno("Confirm", f"Are you sure you want to remove patient {name}?")
            if confirm:
                success = self.patient_management.remove_patient(name)
                if success:
                    messagebox.showinfo("Info", f"Patient {name} removed.")
                else:
                    messagebox.showinfo("Info", f"Patient {name} not found or could not be removed.")
        self.update_queues_display()

    def get_next_patient(self):
        # Create a new window for selecting the specialization
        next_patient_window = tk.Toplevel(self.root)
        next_patient_window.title("Get Next Patient")

        # Label
        tk.Label(next_patient_window, text="Select Specialization:").grid(row=0, column=0, padx=10, pady=10)

        # Specialization selection via dropdown
        specialization = tk.StringVar()
        specialization_dropdown = ttk.Combobox(next_patient_window, textvariable=specialization, values=self.specializations, state="readonly")
        specialization_dropdown.grid(row=0, column=1, padx=10, pady=10)
        specialization_dropdown.set('Select Specialization')

        # Button to confirm selection
        get_btn = tk.Button(next_patient_window, text="Get Next Patient", command=lambda: self.confirm_get_next_patient(specialization.get(), next_patient_window))
        get_btn.grid(row=1, column=0, columnspan=2, pady=10)

    def confirm_get_next_patient(self, specialization, window):
        if specialization == 'Select Specialization':
            messagebox.showinfo("Error", "Please select a specialization.")
            return

        patient = self.patient_management.get_patient(specialization)
        if patient:
            messagebox.showinfo("Next Patient", f"Next patient for {specialization}: {patient.name}")
        else:
            messagebox.showinfo("Next Patient", f"No patients in queue for {specialization}")
        window.destroy()


    def view_edit_patient(self):
        patient_name = simpledialog.askstring("Input", "Enter the patient's name to view/edit:", parent=self.root)
        if not patient_name:
            return

        patient = self.patient_management.get_patient_by_name(patient_name)
        if not patient:
            messagebox.showinfo("Info", f"No patient found with the name {patient_name}.")
            return

        edit_window = tk.Toplevel(self.root)
        edit_window.title("Edit Patient Details")

        # Patient details form
        tk.Label(edit_window, text="Name:").grid(row=0, column=0, padx=10, pady=10)
        name_entry = tk.Entry(edit_window, state='normal')
        name_entry.insert(0, patient.name)
        name_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(edit_window, text="Urgency Status (0=normal, 1=urgent, 2=super urgent):").grid(row=1, column=0, padx=10, pady=10)
        urgency_entry = tk.Entry(edit_window)
        urgency_entry.insert(0, patient.urgency_status)
        urgency_entry.grid(row=1, column=1, padx=10, pady=10)

        save_btn = tk.Button(edit_window, text="Save Changes", command=lambda: self.save_patient_changes(patient.name, urgency_entry.get(), edit_window))
        save_btn.grid(row=3, column=0, columnspan=2, pady=10)

    def save_patient_changes(self, name, new_urgency, edit_window):
        # Update patient details
        self.patient_management.update_patient_urgency(name, new_urgency)
        messagebox.showinfo("Info", "Patient details updated successfully.")
        edit_window.destroy()


    def show_queues(self):
        self.update_queues_display()

    def show_queue_statistics(self):
        stats_window = Toplevel(self.root)
        stats_window.title("Queue Statistics")
        stats_window.geometry("300x250")  # Set the window size

        text_area = tk.Text(stats_window, wrap=tk.WORD)
        text_area.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        queues = self.patient_management.list_queues()
        
        stats_text = []
        for spec, patients in queues.items():
            queue_length = len(patients)
            stats_text.append(f"{spec} - Current Length: {queue_length}")
            avg_wait_time = self.patient_management.get_avg_waiting_time(spec, datetime.now().timestamp())
            stats_text.append(f"Average Wait Time: {avg_wait_time:.2f} minutes")

        display_text = "\n".join(stats_text)
        text_area.insert(tk.END, display_text)
        text_area.config(state=tk.DISABLED)

    def update_queues_display(self):
        queue_window = Toplevel(self.root)
        queue_window.title("Patient Queues")
        queue_window.geometry("300x200") 

        text_area = tk.Text(queue_window, wrap=tk.WORD)
        text_area.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        queues = self.patient_management.list_queues()
        display_text = "\n".join([f"{spec}: {', '.join(patients) if patients else 'No patients'}" for spec, patients in queues.items()])
        text_area.insert(tk.END, display_text)
        text_area.config(state=tk.DISABLED)

    def convert_to_timestamp(self, time_str):
        try:
            hours, minutes = map(int, time_str.split(':'))
            now = datetime.now()
            target_date = datetime(year=now.year, month=now.month, day=now.day,
                                   hour=0, minute=0, second=0, microsecond=0)
            future_time = target_date + timedelta(hours=hours, minutes=minutes)
            return int(future_time.timestamp())
        except ValueError:
            messagebox.showerror("Error", "Invalid time format. Please use DD:HH:MM for time.")
            return None

if __name__ == "__main__":
    root = tk.Tk()
    app = HospitalGUI(root)
    root.mainloop()
